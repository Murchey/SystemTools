﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysTools
{
    public partial class TinyMusic : Form
    {
        public TinyMusic()
        {
            InitializeComponent();
        }
        public void OutPutFiles(byte[] resource, string path)
        {
            FileStream fs = new FileStream(path, FileMode.Create);
            fs.Write(resource, 0, resource.Length);
            fs.Flush();
            fs.Close();
        }
        private void TinyMusic_Load(object sender, EventArgs e)
        {
            try
            {
                if (!File.Exists("社会主义好.mp3"))
                {
                    OutPutFiles(SysTools.Properties.Resources.社会主义好, ".\\music\\社会主义好.mp3");

                }
                if (!File.Exists("国际歌.mp3"))
                {
                    OutPutFiles(SysTools.Properties.Resources.国际歌, ".\\music\\国际歌.mp3");
                }
                if (!File.Exists("1.wav"))
                {
                    OutPutFiles(SysTools.Properties.Resources._1, ".\\music\\1.wav");
                }
                if (!File.Exists("2.wav"))
                {
                    OutPutFiles(SysTools.Properties.Resources._2, ".\\music\\2.wav");
                }
                if (!File.Exists("3.wav"))
                {
                    OutPutFiles(SysTools.Properties.Resources._3, ".\\music\\3.wav");
                }
                if (!File.Exists("4.wav"))
                {
                    OutPutFiles(SysTools.Properties.Resources._4, ".\\music\\4.wav");
                }
                if (!File.Exists("5.wav"))
                {
                    OutPutFiles(SysTools.Properties.Resources._5, ".\\music\\5.wav");
                }
                if (!File.Exists("6.wav"))
                {
                    OutPutFiles(SysTools.Properties.Resources._6, ".\\music\\6.wav");
                }
                if (!File.Exists("7.wav"))
                {
                    OutPutFiles(SysTools.Properties.Resources._7, ".\\music\\7.wav");
                }
            }
            catch { }
        }
        SoundPlayer sd = new SoundPlayer();
        private void bu1_Click(object sender, EventArgs e)
        {
            //Console.Beep(262, 400);
            sd.SoundLocation = @".\music\1.wav";
            sd.Play();
        }

        private void bu2_Click(object sender, EventArgs e)
        {
            //Console.Beep(294, 400);
            sd.SoundLocation = @".\music\2.wav";
            sd.Play();
        }

        private void bu3_Click(object sender, EventArgs e)
        {
            //Console.Beep(330, 400);
            sd.SoundLocation = @".\music\3.wav";
            sd.Play();
        }

        private void bu4_Click(object sender, EventArgs e)
        {
            //Console.Beep(350, 400);
            sd.SoundLocation = @".\music\4.wav";
            sd.Play();
        }

        private void bu5_Click(object sender, EventArgs e)
        {
            //Console.Beep(392, 400);
            sd.SoundLocation = @".\music\5.wav";
            sd.Play();
        }

        private void bu6_Click(object sender, EventArgs e)
        {
            //Console.Beep(440, 400);
            sd.SoundLocation = @".\music\6.wav";
            sd.Play();
        }

        private void bu7_Click(object sender, EventArgs e)
        {
            //Console.Beep(493, 400);
            sd.SoundLocation = @".\music\7.wav";
            sd.Play();
        }

        private void TinyMusic_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.D1:
                    bu1_Click(null, null);
                    break;
                case Keys.D2:
                    bu2_Click(null, null);
                    break;
                case Keys.D3:
                    bu3_Click(null, null);
                    break;
                case Keys.D4:
                    bu4_Click(null, null);
                    break;
                case Keys.D5:
                    bu5_Click(null, null);
                    break;
                case Keys.D6:
                    bu6_Click(null, null);
                    break;
                case Keys.D7:
                    bu7_Click(null, null);
                    break;
                case Keys.NumPad1:
                    bu1_Click(null, null);
                    break;
                case Keys.NumPad2:
                    bu2_Click(null, null);
                    break;
                case Keys.NumPad3:
                    bu3_Click(null, null);
                    break;
                case Keys.NumPad4:
                    bu4_Click(null, null);
                    break;
                case Keys.NumPad5:
                    bu5_Click(null, null);
                    break;
                case Keys.NumPad6:
                    bu6_Click(null, null);
                    break;
                case Keys.NumPad7:
                    bu7_Click(null, null);
                    break;
                default:
                    break;
            }
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
            
        //    //34 55 5117 66 634 55 5432 111 134 55555
        //    //65434 553212 2232 11111 71755 6544 4565
        //    //5511163 565 66512 332
        //    string str = "34-55-5117-66-634-55-5432-111-134-55555-65434-553212-2232-11111-71755-6544-4565-5511163-565-66512-332";
        //    string str1 = "5172153-66416-217654-3335-172153-664621-7247-111132-776716-775545-6621-77712-275545-331671-7216-555132-1153-664121-7765-5505-3325-1177-6562-222132-1153-664121-7765-3333-5543-23414-3322-111";
        //    for (int i = 0; i < str1.Length; i++)
        //    {
        //        switch (str1[i])
        //        {
        //            case '1':
        //                bu1_Click(null, null);
        //                break;
        //            case '2':
        //                bu2_Click(null, null);
        //                break;
        //            case '3':
        //                bu3_Click(null, null);
        //                break;
        //            case '4':
        //                bu4_Click(null, null);
        //                break;
        //            case '5':
        //                bu5_Click(null, null);
        //                break;
        //            case '6':
        //                bu6_Click(null, null);
        //                break;
        //            case '7':
        //                bu7_Click(null, null);
        //                break;
        //            case '-':
        //                Thread.Sleep(100);
        //                break;
        //            default:
        //                break;
        //        }
        //    }
        //}

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedItem.ToString())
            {
                case "明天会更好":
                    pictureBox1.Image = SysTools.Properties.Resources.明天会更好;
                    break;
                case "Pressens Gloria":
                    pictureBox1.Image = SysTools.Properties.Resources.Pressens_Goria;
                    break;
                case "The British Grenadiers":
                    pictureBox1.Image = SysTools.Properties.Resources.The_British_Grenadiers;
                    break;
                case "国际歌":
                    pictureBox1.Image = SysTools.Properties.Resources.国际歌1;
                    break;
                default:
                    break;
            }
        }
    }
}
