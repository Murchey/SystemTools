﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysTools
{
    public partial class GongShiJiSuanQi : Form
    {
        public GongShiJiSuanQi()
        {
            InitializeComponent();
        }

        private void cbKinds_KeyDown(object sender, KeyEventArgs e){}

        private void GongShiJiSuanQi_Load(object sender, EventArgs e)
        {
            cbKinds.SelectedItem = "null";
            cbXingZhuang.SelectedItem = "null";
            pMianJi.Hide();
        }

        private void cbKinds_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (cbKinds.SelectedItem)
                {
                    case "体积类":
                        break;
                    case "单位类":
                        break;
                    case "数学类":
                        break;
                    case "面积类":
                        pMianJi.Show();
                        break;
                    default:
                        break;
                }
            }
            catch { }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (cbXingZhuang.SelectedItem)
                {
                    case "长方形":
                        labelA.Text = "长（w）";
                        labelB.Text = "宽（h）";
                        labelC.Text = "";
                        txtC.Enabled=false;
                        txtD.Enabled = false;
                        labelD.Text = "";
                        pictureBox1.Image = SysTools.Properties.Resources.长方形;
                        break;
                    case "正方形":
                        labelA.Text = "边长（a）";
                        labelB.Text = "";
                        txtB.Enabled=false;
                        labelC.Text = "";
                        txtC.Enabled=false;
                        labelD.Text = "";
                        txtD.Enabled=false;
                        pictureBox1.Image = SysTools.Properties.Resources.长方形;
                        break;
                    case "平行四边形":
                        labelA.Text = "边长(b)";
                        labelB.Text = "高(h)";
                        txtC.Enabled=false;
                        txtD.Enabled=false;
                        labelC.Text = "";
                        labelD.Text = "";
                        pictureBox1.Image = SysTools.Properties.Resources.平行四边形;
                        break;
                    default:
                        break;
                }
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            switch (cbXingZhuang.SelectedItem)
            {
                case "长方形":
                    string[] Changresult =
                        {
                        "计算公式：",
                        "S=a*b",
                        " ="+txtA.Text+"*"+txtB.Text,
                        " ="+Convert.ToDouble(txtA.Text)*Convert.ToDouble(txtB.Text)
                    };
                    for (int i = 0; i < Changresult.Length; i++)
                    {
                        txtResult.AppendText(Changresult[i] + "\r\n");
                    }
                    break;
                case "正方形":
                    string[] Zhengresult =
                        {
                        "计算公式：",
                        "S=a^2",
                        " ="+txtA.Text+"^2",
                        " ="+Convert.ToDouble(txtA.Text)*Convert.ToDouble(txtA.Text)
                    };
                    for (int i = 0; i < Zhengresult.Length; i++)
                    {
                        txtResult.AppendText(Zhengresult[i] + "\r\n");
                    }
                    break;
                case "平行四边形":
                    string[] Pingresult =
               {
                        "计算公式：",
                        "S=b*h",
                        " ="+txtA.Text+"*"+txtB.Text,
                        " ="+Convert.ToDouble(txtA.Text)*Convert.ToDouble(txtB.Text)
                    };
                    for (int i = 0; i < Pingresult.Length; i++)
                    {
                        txtResult.AppendText(Pingresult[i] + "\r\n");
                    }
                    break;
                default:
                    break;
            }
            
        }
    }
}
