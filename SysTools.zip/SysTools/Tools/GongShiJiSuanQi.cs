﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysTools
{
    public partial class GongShiJiSuanQi : Form
    {
        public GongShiJiSuanQi()
        {
            InitializeComponent();
        }

        private void cbKinds_KeyDown(object sender, KeyEventArgs e){}

        private void GongShiJiSuanQi_Load(object sender, EventArgs e)
        {
            cbMathClass.Hide();cbXingZhuang.Hide();cbLiTiXingZhuang.Hide(); txtA.Hide();txtB.Hide();txtC.Hide();txtD.Hide();labelA.Text = "";labelB.Text = "";labelC.Text = "";labelD.Text = "";
        }

        private void cbKinds_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (cbKinds.SelectedItem)
                {
                    case "体积类":
                        cbXingZhuang.Hide();
                        cbLiTiXingZhuang.Show();
                        cbMathClass.Hide();
                        break;
                    case "数学类":
                        cbXingZhuang.Hide();
                        cbLiTiXingZhuang.Hide();
                        cbMathClass.Show();
                        break;
                    case "面积类":
                        cbXingZhuang.Show();
                        cbLiTiXingZhuang.Hide();
                        cbMathClass.Hide();
                        break;
                    default:
                        break;
                }
            }
            catch { }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (cbXingZhuang.SelectedItem)
                {
                    case "长方形":
                        labelA.Text = "长（w）";
                        labelB.Text = "宽（h）";
                        labelC.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtC.Hide();
                        txtD.Hide();
                        labelD.Text = "";
                        pictureBox1.Image = SysTools.Properties.Resources.长方形;
                        break;
                    case "正方形":
                        labelA.Text = "边长（a）";
                        labelB.Text = "";
                        txtA.Show();
                        txtB.Hide();
                        labelC.Text = "";
                        txtC.Hide();
                        labelD.Text = "";
                        txtD.Hide();
                        pictureBox1.Image = SysTools.Properties.Resources.长方形;
                        break;
                    case "平行四边形":
                        labelA.Text = "边长(b)";
                        labelB.Text = "高(h)";
                        txtA.Show();
                        txtB.Show();
                        txtC.Hide();
                        txtD.Hide();
                        labelC.Text = "";
                        labelD.Text = "";
                        pictureBox1.Image = SysTools.Properties.Resources.平行四边形;
                        break;
                    case "圆形":
                        labelA.Text = "半径（r）";
                        labelB.Text = "π取值";
                        labelC.Text = "";
                        labelD.Text = "";
                        txtB.Text = "3.14";
                        txtA.Show();
                        txtB.Show();
                        txtC.Hide();
                        txtD.Hide();
                        pictureBox1.Image = SysTools.Properties.Resources.圆;
                        break;
                    case "椭圆形":
                        labelA.Text = "长轴半径（b）";
                        labelB.Text = "短轴半径（a）";
                        labelC.Text = "π取值";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtC.Show();
                        txtD.Hide();
                        txtC.Text = "3.14";
                        pictureBox1.Image = SysTools.Properties.Resources.椭圆形;
                        break;
                    case "梯形":
                        labelA.Text = "上底（a）";
                        labelB.Text = "下底（b）";
                        labelC.Text = "高（h）";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtC.Show();
                        txtD.Hide();
                        pictureBox1.Image = SysTools.Properties.Resources.梯形;
                        break;
                    case "圆环":
                        labelA.Text = "内径（r）";
                        labelB.Text = "外径（R）";
                        labelC.Text = "π取值";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtC.Show();
                        txtD.Hide();
                        txtC.Text = "3.14";
                        pictureBox1.Image = SysTools.Properties.Resources.圆环;
                        break;
                    case "三角形":
                        labelA.Text = "底边（b）";
                        labelB.Text = "高（h）";
                        labelC.Text = "";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtC.Hide();
                        txtD.Hide();
                        pictureBox1.Image = SysTools.Properties.Resources.三角形;
                        break;
                    default:
                        break;
                }
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                switch (cbXingZhuang.SelectedItem)
                {
                    case "长方形":
                        string[] Changresult =
                            {
                        "计算公式：",
                        "S=a*b",
                        " ="+txtA.Text+"*"+txtB.Text,
                        " ="+Convert.ToDouble(txtA.Text)*Convert.ToDouble(txtB.Text)
                    };
                        for (int i = 0; i < Changresult.Length; i++)
                        {
                            txtResult.AppendText(Changresult[i] + "\r\n");
                        }
                        break;
                    case "正方形":
                        string[] Zhengresult =
                            {
                        "计算公式：",
                        "S=a^2",
                        " ="+txtA.Text+"^2",
                        " ="+Convert.ToDouble(txtA.Text)*Convert.ToDouble(txtA.Text)
                    };
                        for (int i = 0; i < Zhengresult.Length; i++)
                        {
                            txtResult.AppendText(Zhengresult[i] + "\r\n");
                        }
                        break;
                    case "平行四边形":
                        string[] Pingresult =
                   {
                        "计算公式：",
                        "S=b*h",
                        " ="+txtA.Text+"*"+txtB.Text,
                        " ="+Convert.ToDouble(txtA.Text)*Convert.ToDouble(txtB.Text)
                    };
                        for (int i = 0; i < Pingresult.Length; i++)
                        {
                            txtResult.AppendText(Pingresult[i] + "\r\n");
                        }
                        break;
                    case "圆形":
                        string[] Yuanresult =
                   {
                        "计算公式：",
                        "S=π*r^2",
                        " ="+txtB.Text+"*"+txtA.Text+"^2",
                        " ="+Math.Pow(Convert.ToDouble(txtA.Text),2)*Convert.ToDouble(txtB.Text)
                    };
                        for (int i = 0; i < Yuanresult.Length; i++)
                        {
                            txtResult.AppendText(Yuanresult[i] + "\r\n");
                        }
                        break;
                    case "椭圆形":
                        string[] TuoYuanresult =
                   {
                        "计算公式：",
                        "S=π*a*b",
                        " ="+txtC.Text+"*"+txtA.Text+"*"+txtB.Text,
                        " ="+Convert.ToDouble(txtC.Text)*Convert.ToDouble(txtA.Text)*Convert.ToDouble(txtB.Text)
                    };
                        for (int i = 0; i < TuoYuanresult.Length; i++)
                        {
                            txtResult.AppendText(TuoYuanresult[i] + "\r\n");
                        }
                        break;
                    case "梯形":
                        string[] Tiresult =
                   {
                        "计算公式：",
                        "S=(a+b)*h*0.5",
                        " ="+"("+txtA.Text+"+"+txtB.Text+")"+"*"+txtC.Text+"*0.5",
                        " ="+(Convert.ToDouble(txtA.Text)+Convert.ToDouble(txtB.Text))*Convert.ToDouble(txtC.Text)*0.5
                    };
                        for (int i = 0; i < Tiresult.Length; i++)
                        {
                            txtResult.AppendText(Tiresult[i] + "\r\n");
                        }
                        break;
                    case "圆环":
                        string[] Huanresult =
                   {
                        "计算公式：",
                        "S=(R^2-r^2)*π",
                        " ="+"("+txtB.Text+"^2"+txtA.Text+"^2"+")"+"*π",
                        " ="+(Math.Pow(Convert.ToDouble(txtB.Text),2)-Math.Pow(Convert.ToDouble(txtA.Text),2))*Convert.ToDouble(txtC.Text)
                    };
                        for (int i = 0; i < Huanresult.Length; i++)
                        {
                            txtResult.AppendText(Huanresult[i] + "\r\n");
                        }
                        break;
                    case "三角形":
                        string[] Sanresult =
                   {
                        "计算公式：",
                        "S=b*h*0.5",
                        " ="+txtA.Text+"*"+txtB.Text+"*0.5",
                        " ="+Convert.ToDouble(txtA.Text)*Convert.ToDouble(txtB.Text)*0.5
                    };
                        for (int i = 0; i < Sanresult.Length; i++)
                        {
                            txtResult.AppendText(Sanresult[i] + "\r\n");
                        }
                        break;
                    default:
                        break;
                }
                switch (cbLiTiXingZhuang.SelectedItem)
                {
                    case "长方体":
                        string[] Changresult =
                            {
                        "计算公式：",
                        "V=l*w*h",
                        " ="+txtA.Text+"*"+txtB.Text+"*"+txtC.Text,
                        " ="+Convert.ToDouble(txtA.Text)*Convert.ToDouble(txtB.Text)*Convert.ToDouble(txtC.Text)
                    };
                        for (int i = 0; i < Changresult.Length; i++)
                        {
                            txtResult.AppendText(Changresult[i] + "\r\n");
                        }
                        break;
                    case "正方体":
                        string[] Zhengresult =
                            {
                        "计算公式：",
                        "V=l^3",
                        " ="+txtA.Text+"^3",
                        " ="+Math.Pow(Convert.ToDouble(txtA.Text),3)
                    };
                        for (int i = 0; i < Zhengresult.Length; i++)
                        {
                            txtResult.AppendText(Zhengresult[i] + "\r\n");
                        }
                        break;
                    case "球":
                        string[] Qiuresult =
                            {
                        "计算公式：",
                        "V= (4/3)πR^3",
                        " ="+"(4/3)*"+txtB.Text+"*"+txtA.Text+"^3",
                        " ="+(4/3)*(Convert.ToDouble(txtB.Text))*Math.Pow(Convert.ToDouble(txtA.Text),3)
                    };
                        for (int i = 0; i < Qiuresult.Length; i++)
                        {
                            txtResult.AppendText(Qiuresult[i] + "\r\n");
                        }
                        break;
                    case "圆锥":
                        string[] Zhuiresult =
                            {
                        "计算公式：",
                        "V= hπr^2",
                        " ="+txtB.Text+"*"+txtC.Text+"*"+txtA.Text+"^2",
                        " ="+Convert.ToDouble(txtB.Text)*Convert.ToDouble(txtC.Text)+Math.Pow(Convert.ToDouble(txtA.Text),2)
                    };
                        for (int i = 0; i < Zhuiresult.Length; i++)
                        {
                            txtResult.AppendText(Zhuiresult[i] + "\r\n");
                        }
                        break;
                    case "圆柱":
                        string[] Zhuresult =
                            {
                        "计算公式：",
                        "V=πr^2h",
                        " ="+txtC.Text+"*"+txtA.Text+"^2 *"+txtB.Text,
                        " ="+Convert.ToDouble(txtC.Text)*Math.Pow(Convert.ToDouble(txtA.Text),2)*Convert.ToDouble(txtB.Text)
                    };
                        for (int i = 0; i < Zhuresult.Length; i++)
                        {
                            txtResult.AppendText(Zhuresult[i] + "\r\n");
                        }
                        break;
                    default:
                        break;
                }
                switch (cbMathClass.SelectedItem)
                {
                    case "开方":
                        txtResult.Text = "根号下" + txtA.Text + "=" + Math.Sqrt(Convert.ToDouble(txtA.Text));
                        break;
                    case "log(x)Y":
                        txtResult.Text = "log(" + txtA.Text + ")" + txtB.Text + "=" + Math.Log(Convert.ToDouble(txtB.Text), Convert.ToDouble(txtA.Text));
                        break;
                    case "lgY":
                        txtResult.Text = "lg" + txtA.Text + "=" + Math.Log10(Convert.ToDouble(txtA.Text));
                        break;
                    case "lnY":
                        txtResult.Text = "ln" + txtA.Text + "=" + Math.Log(Convert.ToDouble(txtA.Text),Convert.ToDouble(txtB.Text));
                        break;
                    case "二次函数":
                        double DuiChenZhou = (-1 * (2 * Convert.ToDouble(txtA.Text) / Convert.ToDouble(txtB.Text)));
                        string[] Changresult =
                            {
                        "二次函数表达式："+"y="+txtA.Text+"x^2"+"+"+txtB.Text+"x+"+txtC.Text,
                        "对称轴：x="+DuiChenZhou,
                        "最值：y="+(Convert.ToDouble(txtA.Text)*DuiChenZhou*DuiChenZhou+Convert.ToDouble(txtB.Text)*DuiChenZhou+Convert.ToDouble(txtC.Text))
                    };
                        for (int i = 0; i < Changresult.Length; i++)
                        {
                            txtResult.AppendText(Changresult[i] + "\r\n");
                        }
                        break;
                    default:
                        break;
                }
            }
            catch { }
        }

        private void cbLiTiXingZhuang_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (cbLiTiXingZhuang.SelectedItem)
                {
                    case "长方体":
                        labelA.Text = "长(l)";
                        labelB.Text = "宽(w)";
                        labelC.Text = "高(h)";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtC.Show();
                        txtD.Hide();
                        pictureBox1.Image = null;
                        break;
                    case "正方体":
                        labelA.Text = "棱长(l)";
                        labelB.Text = "";
                        labelC.Text = "";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Hide();
                        txtC.Hide();
                        txtD.Hide();
                        pictureBox1.Image = null;
                        break;
                    case "球":
                        labelA.Text = "球半径(r)";
                        labelB.Text = "π取值";
                        labelC.Text = "";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtB.Text = "3.14";
                        txtC.Hide();
                        txtD.Hide();
                        pictureBox1.Image = null;
                        break;
                    case "圆锥":
                        labelA.Text = "圆锥半径(r)";
                        labelB.Text = "高(h)";
                        labelC.Text = "π取值";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtC.Show();
                        txtC.Text = "3.14";
                        txtD.Hide();
                        pictureBox1.Image = null;
                        break;
                    case "圆柱":
                        labelA.Text = "圆柱半径(r)";
                        labelB.Text = "高(h)";
                        labelC.Text = "π取值";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtC.Show();
                        txtC.Text = "3.14";
                        txtD.Hide();
                        pictureBox1.Image = null;
                        break;
                    default:
                        break;
                }
            }
            catch { }
        }

        private void cbMathClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (cbMathClass.SelectedItem)
                {
                    case "开方":
                        labelA.Text = "根号下的数";
                        labelB.Text = "";
                        labelC.Text = "";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Hide();
                        txtC.Hide();
                        txtD.Hide();
                        pictureBox1.Image = null;
                        break;
                    case "log(x)Y":
                        labelA.Text = "底数(x)";
                        labelB.Text = "真数(Y)";
                        labelC.Text = "";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtC.Hide();
                        txtD.Hide();
                        pictureBox1.Image = null;
                        break;
                    case "lgY":
                        labelA.Text = "真数(Y)";
                        labelB.Text = "";
                        labelC.Text = "";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Hide();
                        txtC.Hide();
                        txtD.Hide();
                        pictureBox1.Image = null;
                        break; 
                    case "lnY":
                        labelA.Text = "真数(Y)";
                        labelB.Text = "自然常数e取值(e=2.71828......)";
                        labelC.Text = "";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtB.Text = "2.72";
                        txtC.Hide();
                        txtD.Hide();
                        pictureBox1.Image = null;
                        break;
                    case "二次函数":
                        labelA.Text = "表达式中的a(y=ax^2+bx+c)";
                        labelB.Text = "表达式中的b(y=ax^2+bx+c)";
                        labelC.Text = "表达式中的c(y=ax^2+bx+c)";
                        labelD.Text = "";
                        txtA.Show();
                        txtB.Show();
                        txtC.Show();
                        txtD.Hide();
                        pictureBox1.Image = null;
                        break;
                    default:
                        break;
                }
            }
            catch { }
        }

        private void buDaoChu_Click(object sender, EventArgs e)
        {
          
        }
    }
}
