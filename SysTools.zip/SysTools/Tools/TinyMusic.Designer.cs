﻿
namespace SysTools
{
    partial class TinyMusic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bu1 = new System.Windows.Forms.Button();
            this.bu2 = new System.Windows.Forms.Button();
            this.bu3 = new System.Windows.Forms.Button();
            this.bu4 = new System.Windows.Forms.Button();
            this.bu5 = new System.Windows.Forms.Button();
            this.bu6 = new System.Windows.Forms.Button();
            this.bu7 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bu1
            // 
            this.bu1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bu1.Font = new System.Drawing.Font("黑体", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bu1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.bu1.Location = new System.Drawing.Point(11, 788);
            this.bu1.Name = "bu1";
            this.bu1.Size = new System.Drawing.Size(95, 89);
            this.bu1.TabIndex = 0;
            this.bu1.Text = "1";
            this.bu1.UseVisualStyleBackColor = true;
            this.bu1.Click += new System.EventHandler(this.bu1_Click);
            this.bu1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TinyMusic_KeyDown);
            // 
            // bu2
            // 
            this.bu2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bu2.Font = new System.Drawing.Font("黑体", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bu2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.bu2.Location = new System.Drawing.Point(112, 788);
            this.bu2.Name = "bu2";
            this.bu2.Size = new System.Drawing.Size(95, 89);
            this.bu2.TabIndex = 1;
            this.bu2.Text = "2";
            this.bu2.UseVisualStyleBackColor = true;
            this.bu2.Click += new System.EventHandler(this.bu2_Click);
            this.bu2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TinyMusic_KeyDown);
            // 
            // bu3
            // 
            this.bu3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bu3.Font = new System.Drawing.Font("黑体", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bu3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.bu3.Location = new System.Drawing.Point(213, 788);
            this.bu3.Name = "bu3";
            this.bu3.Size = new System.Drawing.Size(95, 89);
            this.bu3.TabIndex = 2;
            this.bu3.Text = "3";
            this.bu3.UseVisualStyleBackColor = true;
            this.bu3.Click += new System.EventHandler(this.bu3_Click);
            this.bu3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TinyMusic_KeyDown);
            // 
            // bu4
            // 
            this.bu4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bu4.Font = new System.Drawing.Font("黑体", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bu4.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.bu4.Location = new System.Drawing.Point(315, 788);
            this.bu4.Name = "bu4";
            this.bu4.Size = new System.Drawing.Size(95, 89);
            this.bu4.TabIndex = 3;
            this.bu4.Text = "4";
            this.bu4.UseVisualStyleBackColor = true;
            this.bu4.Click += new System.EventHandler(this.bu4_Click);
            this.bu4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TinyMusic_KeyDown);
            // 
            // bu5
            // 
            this.bu5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bu5.Font = new System.Drawing.Font("黑体", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bu5.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.bu5.Location = new System.Drawing.Point(416, 788);
            this.bu5.Name = "bu5";
            this.bu5.Size = new System.Drawing.Size(95, 89);
            this.bu5.TabIndex = 4;
            this.bu5.Text = "5";
            this.bu5.UseVisualStyleBackColor = true;
            this.bu5.Click += new System.EventHandler(this.bu5_Click);
            this.bu5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TinyMusic_KeyDown);
            // 
            // bu6
            // 
            this.bu6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bu6.Font = new System.Drawing.Font("黑体", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bu6.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.bu6.Location = new System.Drawing.Point(517, 788);
            this.bu6.Name = "bu6";
            this.bu6.Size = new System.Drawing.Size(95, 89);
            this.bu6.TabIndex = 5;
            this.bu6.Text = "6";
            this.bu6.UseVisualStyleBackColor = true;
            this.bu6.Click += new System.EventHandler(this.bu6_Click);
            this.bu6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TinyMusic_KeyDown);
            // 
            // bu7
            // 
            this.bu7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bu7.Font = new System.Drawing.Font("黑体", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bu7.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.bu7.Location = new System.Drawing.Point(618, 788);
            this.bu7.Name = "bu7";
            this.bu7.Size = new System.Drawing.Size(95, 89);
            this.bu7.TabIndex = 6;
            this.bu7.Text = "7";
            this.bu7.UseVisualStyleBackColor = true;
            this.bu7.Click += new System.EventHandler(this.bu7_Click);
            this.bu7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TinyMusic_KeyDown);
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox1.ForeColor = System.Drawing.SystemColors.Info;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Pressens Gloria",
            "The British Grenadiers",
            "国际歌",
            "明天会更好"});
            this.comboBox1.Location = new System.Drawing.Point(113, 12);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(600, 28);
            this.comboBox1.TabIndex = 7;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TinyMusic_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(8, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "显示乐谱";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 54);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(692, 714);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // TinyMusic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.ClientSize = new System.Drawing.Size(719, 889);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.bu7);
            this.Controls.Add(this.bu6);
            this.Controls.Add(this.bu5);
            this.Controls.Add(this.bu4);
            this.Controls.Add(this.bu3);
            this.Controls.Add(this.bu2);
            this.Controls.Add(this.bu1);
            this.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "TinyMusic";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TinyMusic-小型音乐模拟软件";
            this.Load += new System.EventHandler(this.TinyMusic_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TinyMusic_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bu1;
        private System.Windows.Forms.Button bu2;
        private System.Windows.Forms.Button bu3;
        private System.Windows.Forms.Button bu4;
        private System.Windows.Forms.Button bu5;
        private System.Windows.Forms.Button bu6;
        private System.Windows.Forms.Button bu7;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}