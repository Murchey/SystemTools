﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysTools
{
    public partial class SysClearForm : Form
    {
        public SysClearForm()
        {
            InitializeComponent();
            cbRubbishBin.CheckState = CheckState.Checked;
            cbTempFolder.CheckState = CheckState.Checked;
            cbRecent.CheckState = CheckState.Checked; 
            
        }
        //string userName=System.Environment.UserName;
        string[] cleanRecentOrders = { "del /Q C:\\Users\\%username%\\Recent",
                                        "del /Q cleanRecent.bat",
                                        "pause"};
        private void button1_Click(object sender, EventArgs e)
        {
            int i = 0;//用于显示提示框
            if(cbRubbishBin.CheckState==CheckState.Checked)
            {
                i++;
                Clean.SHEmptyRecycleBin(this.Handle, "", Clean.SHERB_NOCONFIRMATION + Clean.SHERB_NOPROGRESSUI + Clean.SHERB_NOSOUND);
                Orders.RecordLog("系统清理-清空回收站");
            }//清空回收站
            if(cbTempFolder.CheckState==CheckState.Checked)
            {
                i++;
                string[] temp = {
                    "del /Q C:\\Temp",
                    "del /Q .\\deleteTempFolder.bat"
                };
                File.WriteAllLines(@".\deleteTempFolder.bat", temp);
                Process.Start(".\\deleteTempFolder.bat");
                Orders.RecordLog("系统清理-清空缓存");
            }
            if (cbRecent.CheckState==CheckState.Checked)
            {
                i++;
                File.WriteAllLines("cleanRecent.bat", cleanRecentOrders);
                Process.Start("cleanRecent.bat");
                Orders.RecordLog("系统清理-清空最近使用");
            }
            if (i>0)
            {
                MessageBox.Show("清理已完成！");
                i = 0;
            }
        }
    }
}
