﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysTools
{
    public partial class SysMoreToolsForm : Form
    {
        private object file;

        public SysMoreToolsForm()
        {
            InitializeComponent();
        }

        private void bu_Click(object sender, EventArgs e)
        {
            GongShiJiSuanQi gongShiJiSuanQi = new GongShiJiSuanQi();
            gongShiJiSuanQi.Show();
        }

        private void buSmallChrome_Click(object sender, EventArgs e)
        {
        }
        public void OutPutFiles(byte[] resource, string path)
        {
            FileStream fs = new FileStream(path, FileMode.Create);
            fs.Write(resource, 0, resource.Length);
            fs.Flush();
            fs.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (!(File.Exists("snotepad.exe")))
                {
                    OutPutFiles(Properties.Resources.记事本, "snotepad.exe");
                    Process.Start("snotepad.exe");
                }
                else
                {
                    Process.Start("snotepad.exe");
                }
            }
            catch { }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (!(File.Exists("random_pwd.exe")))
                {
                    OutPutFiles(Properties.Resources.随机密码生成器, "random_pwd.exe");
                    Process.Start("random_pwd.exe");
                }
                else
                {
                    Process.Start("random_pwd.exe");
                }
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!(File.Exists("random_num.exe")))
                {
                    OutPutFiles(Properties.Resources.随机数生成器, "random_num.exe");
                    Process.Start("random_num.exe");
                }
                else
                {
                    Process.Start("random_num.exe");
                }
            }
            catch { }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (!(File.Exists("TOCHAT.exe")))
                {
                    OutPutFiles(Properties.Resources.TOCHAT, "TOCHAT.exe");
                    Process.Start("TOCHAT.exe");
                }
                else
                {
                    Process.Start("TOCHAT.exe");
                }
            }
            catch { }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (!(File.Exists("Alarm.exe")))
                {
                    OutPutFiles(Properties.Resources.倒计时, "倒计时.exe");
                    OutPutFiles(Properties.Resources.计时器, "计时器.exe");
                    OutPutFiles(Properties.Resources.Alarm, "Alarm.exe");
                    Process.Start("Alarm.exe");
                }
                else
                {
                    Process.Start("Alarm.exe");
                }
            }
            catch { }
        }
    }
}
