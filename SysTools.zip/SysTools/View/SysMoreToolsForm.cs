﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysTools
{
    public partial class SysMoreToolsForm : Form
    {
        private object file;

        public SysMoreToolsForm()
        {
            InitializeComponent();
        }

        private void bu_Click(object sender, EventArgs e)
        {
            GongShiJiSuanQi gongShiJiSuanQi = new GongShiJiSuanQi();
            gongShiJiSuanQi.Show();
        }

        private void buSmallChrome_Click(object sender, EventArgs e)
        {
        }
        public void OutPutFiles(byte[] resource,string path)
        {
            FileStream fs = new FileStream(path, FileMode.Create);
            fs.Write(resource, 0, resource.Length);
            fs.Flush();
            fs.Close();
        }
    }
}
