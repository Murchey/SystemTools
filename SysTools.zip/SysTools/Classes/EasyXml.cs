﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace SysTools.Classes
{
    public class EasyXml
    {
        /// <summary>
        /// 创建XML文档并自动添加描述内容，返回一个XmlDocument
        /// </summary>
        /// <returns></returns>
        public static XmlDocument CreateXmlDocument()
        {
            XmlDocument doc = new XmlDocument();
            XmlDeclaration dec = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
            doc.AppendChild(dec);
            return doc;
        }
        /// <summary>
        /// 添加根节点，返回一个XmlElement
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="RootName"></param>
        /// <returns></returns>
        public static XmlElement AppendRootNode(XmlDocument doc, string RootName)
        {
            XmlElement r = doc.CreateElement(RootName);
            doc.AppendChild(r);
            return r;
        }
        /// <summary>
        /// 添加子节点，返回一个XmlElement
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="RootNode"></param>
        /// <param name="ChildName"></param>
        /// <returns></returns>
        public static XmlElement AppendChildNode(XmlDocument doc, XmlNode RootNode, string ChildName)
        {
            XmlElement r = doc.CreateElement(ChildName);
            RootNode.AppendChild(r);
            return r;
        }
        /// <summary>
        /// 改变Xml标签的内容
        /// </summary>
        /// <param name="r"></param>
        /// <param name="InnerText"></param>
        public static void ChangeInnerText(XmlElement r, string InnerText)
        {
            r.InnerText = InnerText;
        }
        /// <summary>
        /// 创建一个标签属性，并写入内容
        /// </summary>
        /// <param name="r"></param>
        /// <param name="AttributeText"></param>
        /// <param name="AttributeValue"></param>
        public static void SetAttribute(XmlElement r, string AttributeText, string AttributeValue)
        {
            r.SetAttribute(AttributeText, AttributeValue);
        }
        /// <summary>
        /// 创建一个标签属性，并且无内容
        /// </summary>
        /// <param name="r"></param>
        /// <param name="AttributeText"></param>
        public static void SetAttribute(XmlElement r, string AttributeText)
        {
            r.SetAttribute(AttributeText, null);
        }
        /// <summary>
        /// 保存文件，也可以用using System.Xml;中的save方法
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="FileName"></param>
        public static void SaveXml(XmlDocument doc, string FileName)
        {
            doc.Save(FileName + ".xml");
        }
    }
}
