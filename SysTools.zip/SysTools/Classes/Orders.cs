﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SysTools
{
     public class Orders
    {
        public static void SendMsg(int n)
        {
            UpdateForm updateForm = new UpdateForm();
            switch (n)
            {
                case 0:
                    Environment.Exit(0);
                    break;
                case 1:
                    Process.Start("iexplore", "https://raw.githubusercontent.com/Murchey/SystemTools/main/TestUpdate.xml");
                    updateForm.Show();
                    break;
                default:
                    break;
            }
        }

        public static void RecordLog(string OperationName)
        {
            string[] content = { "[" + DateTime.Now.ToString() + "]" + "  " + OperationName };
            File.AppendAllLines("UasgeRecord.log",content);
        }
    }
}
